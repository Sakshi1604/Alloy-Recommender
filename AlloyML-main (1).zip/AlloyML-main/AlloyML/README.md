To install and run the gui: 
1. Clone repo
2. Go to "AlloyML" folder
3. Make a virtual environment (preferably) 
4. pip install -r requirements.txt
5. python gui.py
